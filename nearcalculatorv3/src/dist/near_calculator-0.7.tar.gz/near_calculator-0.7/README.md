```This is an calculator made to calculate numbers.```

# How to use
```
sum
=====

sum(1,1)

-------
output
------

2


divide(2,2)

subract(4,4)

multiply(3,3)
```

# setting up directories..

```

├───nearcalculatorv3
│   ├───near_calculator
│   └───src
│       ├───dist
│       ├───example_package_Subdr2nk
│       ├───near_calculator
│       ├───near_calculator.egg-info
│       └───near_models
```

```
Directories.sys($`{import/dist*}`) has been loaded. directories.sys = 'all directories'
```