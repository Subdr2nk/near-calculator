def sum(num , intx):
    return (num + intx)

def subtract(num,intx):
    return (num - intx)

def multiply(num , intx):
    return (num * intx)

def divide(num , intx):
    return (num / intx)
